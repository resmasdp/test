<?php

namespace App\Exceptions;

use Exception;

class FriendlyException extends Exception {

}